﻿using RimWorld;

namespace VFEPirates
{
    public class StorytellerComp_Cursed : StorytellerComp
    {
    }

    public class StorytellerCompProperties_Cursed : StorytellerCompProperties
    {
        public StorytellerCompProperties_Cursed() => compClass = typeof(StorytellerComp_Cursed);
    }
}