﻿
using Verse;
using System;
using RimWorld;



namespace VFEPirates
{

    public static class StaticCollectionsClass
    {

        public static int crewMembersLost = 0;
       
    }
}
